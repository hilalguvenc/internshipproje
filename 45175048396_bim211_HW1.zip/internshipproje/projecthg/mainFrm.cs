﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projecthg
{
    public partial class ınternship : Form
    {
        private DateTime datestartint, dateendint, datestartdep;
        public ınternship()
        {
            InitializeComponent();
        }

        private void mainFrm_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void StartingDateIntChanged(object sender, EventArgs e)
        {
            
        }

        private void EndingDateIntChanged(object sender, EventArgs e)
        {

        }

        private void StartingDateDeptChanged(object sender, EventArgs e)
        {

        }

        private void firmNameChanged(object sender, EventArgs e)
        {

        }

        private void WebChanged(object sender, EventArgs e)
        {

        }

        private void CityChanged(object sender, EventArgs e)
        {

        }

        private void NameSurnameChanged(object sender, EventArgs e)
        {

        }

        private void IdChanged(object sender, EventArgs e)
        {

        }

        private void EmailChanged(object sender, EventArgs e)
        {

        }

        private void CheckboxWorkshopChecked(object sender, EventArgs e)
        {

        }

        private void FinishButton(object sender, EventArgs e)
        {
            Boolean suitable = true;
            if (textId.Text.Length != 11)
            {
                MessageBox.Show("Student Id must be 11 digits");
            }
            else if (!(textEmail.Text.Contains("@anadolu.edu.tr")))
            {
                MessageBox.Show("Student Email Must End With @anadolu.edu.tr");
            }
            else if (textFirmName.Text == "" ||
                textWebSite.Text == "" ||
                textCity.Text == "" ||
                textNameSurname.Text == "" ||
                textEmail.Text == "" ||
                textId.Text == "")
            {
                MessageBox.Show("Please Fill The Required Fields");    
            }
            else
            {
                if (semestercalc() < 4)
                {
                    suitable = false;
                    labelSemester.Text = "Semester completed is less than 4";
                }
                if (!(checkBoxCourses.Checked))
                {
                    suitable = false;
                    labelCouses.Text = "You did not completed the required courses";
                }
                if (!(checkBoxWorkshop.Checked))
                {
                    suitable = false;
                    labelWorkshop.Text = "The Firm does not have a workshop or at least one engineer ";  
                }
                if (datediff() < 20)
                {
                    suitable = false;
                    labeldays.Text = "Your duration of internship must be greater than 20 days";
                }
                if (suitable)
                {
                    labelSuitable.Text = "SUITABLE";
                    labelSuitable.ForeColor = Color.Red;
                    labelSemester.Text = "";
                    labelCouses.Text = "";
                    labelWorkshop.Text = "";
                    labeldays.Text = "";
                }
                else
                {
                    labelSuitable.Text = "NOT SUITABLE";
                    labelSuitable.ForeColor = Color.Red;
                }
            }
        }

        private void ChechboxSaturdayChecked(object sender, EventArgs e)
        {

        }

        private void CheckboxCoursesChecked(object sender, EventArgs e)
        {

        }

        private int datediff()
        {
            TimeSpan diff = dateEndingInternship.Value - dateStartingInternship.Value;     //date difference between the ending date of the internship and starting date of the internship
            int week = (diff.Days+1) / 7;
            int ret = 0;
            if (checkBoxSaturday.Checked)
            {
                ret = (diff.Days + 1) - week;
            }else
            {
                ret = (diff.Days + 1) - (2 * week);
            }
            return ret;    //taking the days of the diff object
        }

        private int semestercalc()
        {
            TimeSpan diff = DateTime.Today - dateStartingDepartment.Value;  //date difference between present day and starting date of the department
            return (int)(diff.Days / 30) / 6;   //taking days of the diff object and evaluates to the months and evaluates to the semester, and returns the semester.
        }
    }
}
